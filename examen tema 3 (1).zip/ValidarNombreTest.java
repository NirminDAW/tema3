package com.mycompany.validarnombre;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author nirmi
 */
public class ValidarNombreTest {
    
    public ValidarNombreTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of tieneLongitudCorrecta method, of class ValidarNombre.
     */
  

    @Test
    public void testTieneLongitudCorrecta() {
        assertTrue(ValidarNombre.tieneLongitudCorrecta("Santana Molina, Luis"));
    }

    @Test
    public void testTieneLongitudIncorrecta() {
        assertFalse(ValidarNombre.tieneLongitudCorrecta("Santana Molina"));
        assertFalse(ValidarNombre.tieneLongitudCorrecta("Luis"));
        assertFalse(ValidarNombre.tieneLongitudCorrecta("Santana Molina, Luis Torres"));
    }

    @Test
    public void testTieneComaAlFinal() {
        assertTrue(ValidarNombre.tieneComaAlFinal("Molina,"));
    }

    @Test
    public void testNoTieneComaAlFinal() {
        assertFalse(ValidarNombre.tieneComaAlFinal("Molina"));
        assertFalse(ValidarNombre.tieneComaAlFinal("Molina Luis"));
    }

    @Test
    public void testTieneSoloPrimeraLetraMayuscula() {
        assertTrue(ValidarNombre.tieneSoloPrimeraLetraMayuscula("Molina"));
    }

    @Test
    public void testNoTieneSoloPrimeraLetraMayuscula() {
        assertFalse(ValidarNombre.tieneSoloPrimeraLetraMayuscula("molina"));
        assertFalse(ValidarNombre.tieneSoloPrimeraLetraMayuscula("MOlina"));
    }

    @Test
    public void testExistePalabraEnVector() {
        String[] vector = {"ARTILES", "BLANCO", "RAMOS", "SANTANA", "MOLINA"};
        assertTrue(ValidarNombre.existePalabraEnVector("MOLINA", vector));
    }

    @Test
    public void testNoExistePalabraEnVector() {
        String[] vector = {"ARTILES", "BLANCO", "RAMOS", "SANTANA", "MOLINA"};
        assertFalse(ValidarNombre.existePalabraEnVector("TORRES", vector));
    }

    @Test
    public void testValidarNombreCorrecto() {
        assertTrue(ValidarNombre.validarNombre("Santana Molina, Luis"));
    }

    @Test
    public void testValidarNombreIncorrecto() {
        assertFalse(ValidarNombre.validarNombre("Santana Molina Luis"));
        assertFalse(ValidarNombre.validarNombre("Blanco Ramos, Ana Santana Molina"));
    }

    }
